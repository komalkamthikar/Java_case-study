package com.bookutil;

import java.util.ArrayList;
import java.util.Scanner;

public class Book {
	String bookID;
	String title;
	String author;
	float price;
	String category;

	Scanner sc = new Scanner(System.in);

	public Book(String bookID, String title, String author, float price, String category) {
		
		this.bookID = bookID;
		this.title = title;
		this.author = author;
		this.price = price;
		this.category = category;
	}

	public String getBookID() {
		return bookID;
	}

	public String setBookID(String bookID) {
		return this.bookID = bookID;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String toString() {
		return "The details of the book are:" + bookID + "," + title + ", " + author + ", " + category + ", " + price;
	}

	
	public Book() throws InvalidBookException {
		try {
			String science="Science";
			String fiction="Fiction";
			String technology="Technology";
			String others="Others";
			if(category.equals(science) || category.equals(fiction) || category.equals(technology) || category.equals(others)) 
			{
				this.category=category;
			} 
			else {
				String msg="Category either be science or Fiction or Technology or others";
				throw new InvalidBookException(msg);
			}
		}
		catch(InvalidBookException msg) {
			System.out.println(msg);
		}

	try {
		if (!(bookID.startsWith("B") && bookID.length() == 4)) {
			String msg = "BookId should start with B and length should not be less than 4";
			throw new InvalidBookException(msg);
		}
	} catch (InvalidBookException msg) {
		System.out.println(msg);
	}
	try {
		if (price <= 0) {
			String msg = "Price cannot be negative";
			throw new InvalidBookException(msg);
		}
	} catch (InvalidBookException msg) {
		System.out.println(msg);
	}
	}

}

