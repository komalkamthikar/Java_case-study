package com.bookutil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Scanner;

public class BookStore {
	ArrayList<Book> booklist=new ArrayList<Book>();
	Scanner sc=new Scanner(System.in);
	
	public void addBook(Book b) {
		booklist.add(b);
	}
	
	public void modifybook(String id) {
		Iterator itr=booklist.iterator();
		while(itr.hasNext()) {
			Book myBook=(Book)itr.next();
			String id1=myBook.getBookID();
			if(id1.equals(id)) {
				System.out.println("Enter the field to modify");
				String field=sc.nextLine();
				switch(field) {
				case "id":
					System.out.println("Enter the modified Id : ");
					String modifyId=sc.nextLine();
					myBook.setBookID(modifyId);
					break;
				case "title":
					System.out.println("Enter the modified title : ");
					String modifyTitle=sc.nextLine();
					myBook.setTitle(modifyTitle);
					break;
				case "author":
					System.out.println("Enter the modified Author : ");
					String modifyAuthor=sc.nextLine();
					myBook.setAuthor(modifyAuthor);
					break;
				case "Price":
					System.out.println("Enter the modified Price : ");
					float modifyPrice=sc.nextFloat();
					myBook.setPrice(modifyPrice);
					break;
				case "category":
					System.out.println("Enter the modified category : ");
					String modifyCategory=sc.nextLine();
					myBook.setCategory(modifyCategory);
					break;
				}
				
			}
		}
	}
	public void deleteBook(String bookid) {
		Iterator<Book> itr=booklist.iterator();
		while(itr.hasNext()) {
			Book str=itr.next();
			String id1=str.getBookID();
			if(id1.equals(id1)) {
				itr.remove();
			}
		}
	}
	public void displayAll() {
		Iterator<Book> itr=booklist.iterator();
		while(itr.hasNext()) {
			Book str=itr.next();
			String book_id=str.getBookID();
			String book_title=str.getTitle();
			String book_author=str.getAuthor();
			float  book_price=str.getPrice();
			String book_category=str.getCategory();
			System.out.println("BookId:"+book_id+"\tBookTitle:"+book_title+"\t"+"Book_Author"+book_author+"\tBook_Price:"+book_price+"\tBook_Category"+book_category);
			}
	}
	public void displaySpecific(String id) {
		Iterator<Book> itr=booklist.iterator();
		while(itr.hasNext()) {
			Book str=itr.next();
			String book_id1=str.getBookID();
			String book_title1=str.getTitle();
			String book_author1=str.getAuthor();
			float  book_price1=str.getPrice();
			String book_category1=str.getCategory();
			if(book_id1.equals(id)) {
				System.out.println("BookId:"+book_id1+"\tBookTitle:"+book_title1+"\t"+"Book_Author"+book_author1+"\tBook_Price:"+book_price1+"\tBook_Category"+book_category1);
			}
		}
	}
	public void SearchByTitle(String title) {
		Iterator<Book> itr=booklist.iterator();
		while(itr.hasNext()) {
			Book str=itr.next();
			String book_id1=str.getBookID();
			String book_title1=str.getTitle();
			String book_author1=str.getAuthor();
			float  book_price1=str.getPrice();
			String book_category1=str.getCategory();
			if(book_title1.equals(title)) {
				System.out.println("BookId:"+book_id1+"\tBookTitle:"+book_title1+"\t"+"Book_Author"+book_author1+"\tBook_Price:"+book_price1+"\tBook_Category"+book_category1);
				}
			}
		}
	public void SearchByAuthor(String author) {
		Iterator<Book> itr=booklist.iterator();
		while(itr.hasNext()) {
			Book str=itr.next();
			String book_id1=str.getBookID();
			String book_title1=str.getTitle();
			String book_author1=str.getAuthor();
			float  book_price1=str.getPrice();
			String book_category1=str.getCategory();
			if(book_author1.equals(author)) {
				System.out.println("BookId:"+book_id1+"\tBookTitle:"+book_title1+"\t"+"Book_Author"+book_author1+"\tBook_Price:"+book_price1+"\tBook_Category"+book_category1);
				}
			}
		}
}
		
	
	    

	    