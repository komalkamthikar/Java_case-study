package com.bookutil;

import java.util.Scanner;

public class BookUtil{
	public static void main(String[] args) {
		BookStore bookstore=new BookStore();
		Scanner scan = new Scanner(System.in);
		int option = 0;
		while(option!=8) {
			System.out.println("\n1.Add\n2.Modify\n3.Delete\n4.DisplayAll\n5.DisplaySpecific\n6.Search_book_by_Title\n7.Search_book_by_Author\n8.Exit");
			option=scan.nextInt();
			switch(option) {
			case 1:
				System.out.println("Enter Book_Id:");
				String id=scan.next();
				System.out.println("Enter Book_Title:");
				String title=scan.next();
				System.out.println("Enter Book_Author:");
				String author=scan.next();
				System.out.println("Enter Book_Price:");
				float price=scan.nextFloat();
				System.out.println("Enter Book_Category:");
				String category=scan.next();
				
				Book book=new Book(id,title,author,price,category);
				bookstore.addBook(book);
				System.out.println("Book Added Successfully!");
				break;
			case 2:
				System.out.println("Enter Book_id to Modify:");
				String id1=scan.next();
				bookstore.modifybook(id1);
				System.out.println("Modified Successfully!");
				break;
			case 3:
				System.out.println("Enter Book_Id to Delete:");
				String id2=scan.next();
				bookstore.deleteBook(id2);
				System.out.println("Book Deleted Successfully!");
				break;
			case 4:
				bookstore.displayAll();
				break;
			case 5:
				System.out.println("Enter Book_id to display:");
				String id3=scan.next();
				bookstore.displaySpecific(id3);
				System.out.println("Displayed!");
				break;
			case 6:
				System.out.println("Enter book_Title to search:");
				String title1=scan.next();
				bookstore.SearchByTitle(title1);
				break;
			case 7:
				System.out.println("Enter book_Author to search");
				String author1=scan.next();
				bookstore.SearchByAuthor(author1);
				break;
			case 8:
				System.out.println("Exit!");
				}
			
		}
	}
}


	
	


