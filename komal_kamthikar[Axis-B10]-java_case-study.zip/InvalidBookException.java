package com.bookutil;

public class InvalidBookException extends Exception {

	public InvalidBookException(String s) {
		super(s);
		
	}

	
}
